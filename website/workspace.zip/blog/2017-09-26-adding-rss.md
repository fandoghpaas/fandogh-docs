---
title: Adding RSS Support
author: Eric Nakagawa
authorURL: http://twitter.com/ericnakagawa
authorFBID: 661277173
---

This is a test post.

A whole bunch of other information.
