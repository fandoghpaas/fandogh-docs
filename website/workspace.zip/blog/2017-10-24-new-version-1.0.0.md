---
title: New Version 1.0.0
author: Eric Nakagawa
authorURL: http://twitter.com/ericnakagawa
authorFBID: 661277173
---

This blog post will test file name parsing issues when periods are present.
